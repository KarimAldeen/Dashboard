export  const SideBarLogoUrl = "../Layout/KarimLogo.svg";
export  const SideBarName = "Karim_Aldeen";