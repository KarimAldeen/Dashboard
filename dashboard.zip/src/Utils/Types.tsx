export  interface FormTableState {
    objectToEdit: any[]; 
    OpenEdit: boolean;
    OpenAdd: boolean;
  }