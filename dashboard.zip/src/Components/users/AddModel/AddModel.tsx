'use client'
import { Form, Formik } from 'formik';
import React from 'react';
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';
import AddModelBody from './AddModelBody';
import { getDataToSend, getInitialValues, getValidationSchema } from '../Formik';
import { ServerApi } from './AddServier';

const AddModel = ({ FormTable,setFormTable} : any) => {
  
  const handleSubmit = (values : any) => {
  
    ServerApi(values)
    setFormTable((pre:any)=>({...pre,["OpenAdd"]:false}))
  }
  return (
    <Modal isOpen={FormTable["OpenAdd"]} centered size={"lg"}>
      <ModalHeader toggle={() => setFormTable((pre:any)=>({...pre,["OpenAdd"]:false})) }>
        {("Add_new user")}
      </ModalHeader>
      <Formik
        onSubmit={(values)=>handleSubmit(values)}
        initialValues={getInitialValues(FormTable["objectToAdd"])}
        validationSchema={getValidationSchema()}
      >
        {(formik) => (
          <Form>
            <ModalBody>
              <AddModelBody/>
            </ModalBody>
            <ModalFooter>
              <Button  onClick={() => setFormTable((pre:any)=>({...pre,["OpenAdd"]:false})) } color='danger'>
                {('cancel')}
              </Button>
              <Button type='submit' color='primary'  className='Model_Button'>
                {('submit')}
              </Button>
            </ModalFooter>
          </Form>
        )}
      </Formik>
    </Modal>
  );
};

export default AddModel;