import TranslateText from '@/Hooks/useTranslateText';
import React from 'react';

const Page = () => {

  return (
    <div><TranslateText text='Ar' /></div>
  );
}

export default Page;
