import Loading2 from '@/Components/Utils/Loading/Loading2'
import React from 'react'

const Loading = () => {
  return (
   <Loading2/>
  )
}

export default Loading